import subprocess
import sys
import tkinter as tk
from pathlib import Path
from tkinter import messagebox


BASE_DIR = Path(__file__).resolve().parent
BACKGROUND_IMAGE = BASE_DIR / "assets" / "menu_background.png"

WINDOW_WIDTH = 1166
WINDOW_HEIGHT = 656


class LauncherApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Batalla Naval - Menu Principal")
        self.root.geometry(f"{WINDOW_WIDTH}x{WINDOW_HEIGHT}")
        self.root.resizable(False, False)
        self.root.configure(bg="#171922")
        self.processes = []
        self.hovered_option = None
        self.bg_image = None

        self.options = [
            {
                "key": "server",
                "label": "SERVIDOR",
                "script": "server.py",
                "center": (982, 158),
                "radius": 94,
                "label_pos": (982, 286),
            },
            {
                "key": "local",
                "label": "LOCAL",
                "script": "gui_game.py",
                "center": (162, 476),
                "radius": 102,
                "label_pos": (162, 586),
            },
            {
                "key": "client",
                "label": "Multijugador",
                "script": "gui_multiplayer_client.py",
                "center": (996, 477),
                "radius": 96,
                "label_pos": (996, 586),
            },
        ]

        self.build_ui()

    def build_ui(self):
        self.canvas = tk.Canvas(
            self.root,
            width=WINDOW_WIDTH,
            height=WINDOW_HEIGHT,
            bg="#171922",
            highlightthickness=0,
            cursor="arrow",
        )
        self.canvas.pack(fill="both", expand=True)

        self.draw_background()
        self.draw_mode_labels()
        self.draw_hover(None)

        self.canvas.bind("<Motion>", self.on_motion)
        self.canvas.bind("<Leave>", self.on_leave)
        self.canvas.bind("<Button-1>", self.on_click)

    def draw_background(self):
        if BACKGROUND_IMAGE.exists():
            self.bg_image = tk.PhotoImage(file=str(BACKGROUND_IMAGE))
            self.canvas.create_image(0, 0, image=self.bg_image, anchor="nw")
            return

        self.canvas.create_rectangle(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT, fill="#1c1d27", outline="")
        self.canvas.create_oval(390, 38, 778, 426, fill="#ef2d2d", outline="")
        self.canvas.create_text(
            WINDOW_WIDTH // 2,
            88,
            text="BATALLA NAVAL",
            fill="#f2d6d6",
            font=("Georgia", 42, "bold"),
        )
        self.canvas.create_text(
            WINDOW_WIDTH // 2,
            134,
            text="No se encontro la imagen de fondo. El menu sigue funcionando.",
            fill="#f6b0b8",
            font=("Segoe UI", 14, "bold"),
        )

    def draw_mode_labels(self):
        for option in self.options:
            x, y = option["label_pos"]
            self.canvas.create_text(
                x + 2,
                y + 2,
                text=option["label"],
                fill="#08090d",
                font=("Georgia", 18, "bold"),
                tags=(option["key"], "mode_label"),
            )
            self.canvas.create_text(
                x,
                y,
                text=option["label"],
                fill="#f3e8e2",
                font=("Georgia", 18, "bold"),
                tags=(option["key"], "mode_label"),
            )

    def draw_hover(self, option):
        self.canvas.delete("hover")
        if option is None:
            return

        x, y = option["center"]
        r = option["radius"] + 8
        self.canvas.create_oval(
            x - r,
            y - r,
            x + r,
            y + r,
            outline="#ffd1dc",
            width=4,
            tags="hover",
        )
        self.canvas.create_oval(
            x - r + 8,
            y - r + 8,
            x + r - 8,
            y + r - 8,
            outline="#ff496d",
            width=2,
            tags="hover",
        )

    def on_motion(self, event):
        option = self.option_at(event.x, event.y)
        if option == self.hovered_option:
            return

        self.hovered_option = option
        self.draw_hover(option)
        self.canvas.configure(cursor="hand2" if option else "arrow")

    def on_leave(self, event):
        self.hovered_option = None
        self.draw_hover(None)
        self.canvas.configure(cursor="arrow")

    def on_click(self, event):
        option = self.option_at(event.x, event.y)
        if option is None:
            return

        self.open_script(option["script"])

    def option_at(self, x, y):
        for option in self.options:
            cx, cy = option["center"]
            radius = option["radius"]
            if (x - cx) ** 2 + (y - cy) ** 2 <= radius**2:
                return option
        return None

    def open_script(self, script):
        path = BASE_DIR / script
        try:
            process = subprocess.Popen([sys.executable, str(path)], cwd=str(BASE_DIR))
            self.processes.append(process)
        except Exception as exc:
            messagebox.showerror("No se pudo abrir", str(exc))


def main():
    root = tk.Tk()
    LauncherApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
