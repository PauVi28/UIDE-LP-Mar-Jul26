from game_logic import BOARD_SIZE, Board


def prompt_place_fleet_manual(player_name):
    ships = []

    print(f"\nColoca la flota de {player_name}")

    for size in [5, 4, 3, 3, 2]:
        while True:
            try:
                text = input(
                    f"Barco tamano {size}. Inicio r c y final r c (ej: 0 0 0 4): "
                ).strip()
                parts = list(map(int, text.split()))

                if len(parts) != 4:
                    print("Debes ingresar 4 numeros.")
                    continue

                r1, c1, r2, c2 = parts
                coords = Board()._coords_between((r1, c1), (r2, c2))

                if coords is None or len(coords) != size:
                    print("El barco debe ser horizontal o vertical y tener el tamano correcto.")
                    continue

                ships.append([[r1, c1], [r2, c2]])
                break
            except ValueError:
                print("Usa solo numeros separados por espacios.")

    return ships


def play_local(auto=False):
    board1 = Board()
    board2 = Board()

    if auto:
        ships1 = board1.random_place_all()
        ships2 = board2.random_place_all()
    else:
        ships1 = prompt_place_fleet_manual("Jugador 1")
        ships2 = prompt_place_fleet_manual("Jugador 2")

    ok1, err1 = board1.place_fleet(ships1)
    ok2, err2 = board2.place_fleet(ships2)

    if not ok1:
        print("Flota invalida para Jugador 1:", err1)
        return
    if not ok2:
        print("Flota invalida para Jugador 2:", err2)
        return

    current = 1

    while True:
        target = board2 if current == 1 else board1

        print(f"\nTurno del Jugador {current}")
        while True:
            try:
                text = input("Ingresa coordenada r c: ").strip()
                r, c = map(int, text.split())

                if not (0 <= r < BOARD_SIZE and 0 <= c < BOARD_SIZE):
                    print("Coordenada fuera del tablero.")
                    continue

                result, sunk = target.receive_shot((r, c))

                if result == "repetida":
                    print("Ya disparaste ahi. Intenta otra coordenada.")
                    continue

                print("Resultado:", result)
                if sunk:
                    print("Hundido:", [list(coord) for coord in sunk])
                break
            except ValueError:
                print("Ingresa dos numeros separados por espacio.")

        if target.all_sunk():
            print(f"\nGano el Jugador {current}.")
            break

        if result == "agua":
            current = 2 if current == 1 else 1
        else:
            print(f"Jugador {current} acerto y conserva el turno.")


if __name__ == "__main__":
    mode = input("Modo local - colocar barcos automaticamente? (y/n): ").strip().lower()
    play_local(auto=(mode == "y"))
