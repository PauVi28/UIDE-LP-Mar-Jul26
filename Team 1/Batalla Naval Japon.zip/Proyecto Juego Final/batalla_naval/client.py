import argparse
import json
import socket

from game_logic import BOARD_SIZE, Board


SERVER_TIMEOUT = 0.5


def send_json(conn, obj):
    conn.sendall((json.dumps(obj) + "\n").encode())


def recv_json(conn, buffer):
    while "\n" not in buffer[0]:
        chunk = conn.recv(4096).decode(errors="ignore")
        if not chunk:
            raise ConnectionError("closed")
        buffer[0] += chunk

    line, rest = buffer[0].split("\n", 1)
    buffer[0] = rest

    try:
        return json.loads(line)
    except json.JSONDecodeError:
        return {"type": "error", "message": "bad_json"}


def interactive_place():
    ships = []

    for size in [5, 4, 3, 3, 2]:
        while True:
            try:
                text = input(
                    f"Barco tamano {size}. Ingresa inicio r c y final r c (ej: 0 0 0 4): "
                ).strip()
                parts = list(map(int, text.split()))

                if len(parts) != 4:
                    print("Debes ingresar 4 numeros.")
                    continue

                r1, c1, r2, c2 = parts
                coords = Board()._coords_between((r1, c1), (r2, c2))

                if coords is None or len(coords) != size:
                    print("El barco debe ser horizontal o vertical y tener el tamano correcto.")
                    continue

                ships.append([[r1, c1], [r2, c2]])
                break
            except ValueError:
                print("Usa solo numeros separados por espacios.")

    return ships


def random_place():
    board = Board()
    return board.random_place_all()


def handle_server_message(sock, buffer, auto):
    try:
        msg = recv_json(sock, buffer)
    except socket.timeout:
        return True

    if not isinstance(msg, dict):
        return True

    msg_type = msg.get("type")

    if msg_type == "request" and msg.get("what") == "place_fleet":
        ships = random_place() if auto else interactive_place()
        send_json(sock, {"type": "place_fleet", "ships": ships})
    elif msg_type == "state":
        if msg.get("your_turn"):
            print("\n--- Es tu turno ---")
            send_move(sock)
        else:
            print("\n--- Espera turno del rival ---")
    elif msg_type == "result":
        print(f"Resultado: {msg.get('from')} disparo a {msg.get('coord')} => {msg.get('result')}")
        if msg.get("sunk_coords"):
            print("Hundido en coords:", msg.get("sunk_coords"))
    elif msg_type == "end":
        if "winner" in msg:
            print("Juego terminado. Ganador:", msg["winner"])
        else:
            print("Juego terminado:", msg.get("message"))
        return False
    elif msg_type == "ack":
        print("Servidor:", msg.get("message"))
    elif msg_type == "error":
        print("Error del servidor:", msg.get("message"))
    else:
        print("Mensaje servidor:", msg)

    return True


def send_move(sock):
    while True:
        try:
            text = input("Ingresa coordenada r c (ej: 3 5): ").strip()
            r, c = map(int, text.split())

            if not (0 <= r < BOARD_SIZE and 0 <= c < BOARD_SIZE):
                print("Coordenada fuera del tablero.")
                continue

            send_json(sock, {"type": "move", "coord": [r, c]})
            return
        except ValueError:
            print("Ingresa dos numeros separados por espacio.")


def run_client(host, port, name, auto):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(5)

    try:
        sock.connect((host, port))
    except Exception as exc:
        print("No se pudo conectar al servidor:", exc)
        return

    sock.settimeout(SERVER_TIMEOUT)
    buffer = [""]

    try:
        msg = recv_json(sock, buffer)
        if msg.get("type") == "request_handshake":
            send_json(sock, {"type": "handshake", "name": name})

        running = True
        while running:
            running = handle_server_message(sock, buffer, auto)
    except KeyboardInterrupt:
        pass
    except ConnectionError:
        print("Conexion cerrada por el servidor.")
    finally:
        sock.close()


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=5000)
    parser.add_argument("--name", default="jugador")
    parser.add_argument("--auto", action="store_true")
    args = parser.parse_args()

    run_client(args.host, args.port, args.name, args.auto)
