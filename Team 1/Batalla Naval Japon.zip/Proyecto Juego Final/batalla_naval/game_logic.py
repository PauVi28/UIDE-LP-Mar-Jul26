import random


BOARD_SIZE = 10
SHIP_SIZES = [5, 4, 3, 3, 2]


class Board:
    def __init__(self):
        self.grid = [[0] * BOARD_SIZE for _ in range(BOARD_SIZE)]
        self.ships = []
        self.hits_per_ship = []

    def in_bounds(self, coord):
        r, c = coord
        return 0 <= r < BOARD_SIZE and 0 <= c < BOARD_SIZE

    def _coords_between(self, start, end):
        r1, c1 = start
        r2, c2 = end
        coords = []

        if r1 == r2:
            step = 1 if c2 >= c1 else -1
            for c in range(c1, c2 + step, step):
                coords.append((r1, c))
        elif c1 == c2:
            step = 1 if r2 >= r1 else -1
            for r in range(r1, r2 + step, step):
                coords.append((r, c1))
        else:
            return None

        return coords

    def place_ship(self, start, end):
        if not (self.in_bounds(start) and self.in_bounds(end)):
            return False

        coords = self._coords_between(start, end)
        if coords is None:
            return False

        for r, c in coords:
            if self.grid[r][c] != 0:
                return False

        for r, c in coords:
            self.grid[r][c] = 1

        self.ships.append(set(coords))
        self.hits_per_ship.append(0)
        return True

    def validate_fleet(self, ships):
        if len(ships) != len(SHIP_SIZES):
            return False, "fleet_size_mismatch"

        sizes = []
        tmp_grid = [[0] * BOARD_SIZE for _ in range(BOARD_SIZE)]

        for ship in ships:
            try:
                start = tuple(ship[0])
                end = tuple(ship[1])
            except Exception:
                return False, "invalid_ship_format"

            coords = self._coords_between(start, end)
            if coords is None:
                return False, "diagonal_or_invalid"

            for r, c in coords:
                if not (0 <= r < BOARD_SIZE and 0 <= c < BOARD_SIZE):
                    return False, "out_of_bounds"
                if tmp_grid[r][c] != 0:
                    return False, "overlap"
                tmp_grid[r][c] = 1

            sizes.append(len(coords))

        if sorted(sizes) != sorted(SHIP_SIZES):
            return False, "wrong_ship_sizes"

        return True, None

    def place_fleet(self, ships):
        ok, err = self.validate_fleet(ships)
        if not ok:
            return False, err

        self.grid = [[0] * BOARD_SIZE for _ in range(BOARD_SIZE)]
        self.ships = []
        self.hits_per_ship = []

        for ship in ships:
            start = tuple(ship[0])
            end = tuple(ship[1])
            self.place_ship(start, end)

        return True, None

    def random_place_all(self):
        for _ in range(50):
            self.grid = [[0] * BOARD_SIZE for _ in range(BOARD_SIZE)]
            self.ships = []
            self.hits_per_ship = []
            success = True

            for size in SHIP_SIZES:
                placed = False

                for _ in range(200):
                    orient = random.choice(["h", "v"])

                    if orient == "h":
                        r = random.randrange(0, BOARD_SIZE)
                        c = random.randrange(0, BOARD_SIZE - size + 1)
                        start = (r, c)
                        end = (r, c + size - 1)
                    else:
                        r = random.randrange(0, BOARD_SIZE - size + 1)
                        c = random.randrange(0, BOARD_SIZE)
                        start = (r, c)
                        end = (r + size - 1, c)

                    if self.place_ship(start, end):
                        placed = True
                        break

                if not placed:
                    success = False
                    break

            if success:
                out = []
                for ship in self.ships:
                    coords = sorted(ship)
                    out.append([list(coords[0]), list(coords[-1])])
                return out

        raise RuntimeError("No se pudo colocar la flota aleatoriamente.")

    def receive_shot(self, coord):
        if not self.in_bounds(coord):
            return "invalid", None

        r, c = coord
        val = self.grid[r][c]

        if val in (2, 3):
            return "repetida", None

        if val == 1:
            self.grid[r][c] = 2
            for idx, ship in enumerate(self.ships):
                if (r, c) in ship:
                    self.hits_per_ship[idx] += 1
                    if self.hits_per_ship[idx] >= len(ship):
                        return "hundido", sorted(ship)
                    return "impacto", None

        self.grid[r][c] = 3
        return "agua", None

    def all_sunk(self):
        return all(hits >= len(ship) for hits, ship in zip(self.hits_per_ship, self.ships))

    def as_public(self, hide_ships=True):
        out = []

        for r in range(BOARD_SIZE):
            row = []
            for c in range(BOARD_SIZE):
                val = self.grid[r][c]
                if hide_ships and val == 1:
                    row.append(0)
                else:
                    row.append(val)
            out.append(row)

        return out
