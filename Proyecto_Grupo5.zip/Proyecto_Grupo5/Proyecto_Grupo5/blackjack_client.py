import socket
import threading
import queue
import json
import tkinter as tk
from tkinter import messagebox

PORT = 5555

def valor_carta(carta):
    v = carta[:-1]
    if v in ["J", "Q", "K"]:
        return 10
    if v == "A":
        return 11
    return int(v)

def calcular_mano(mano):
    total = sum(valor_carta(c) for c in mano)
    ases = sum(1 for c in mano if c[:-1] == "A")
    while total > 21 and ases:
        total -= 10
        ases -= 1
    return total

sock = None
cola = queue.Queue()
mano_local = []
cartas_rival = []
fase = "sin_conectar"
nombre_local = "Jugador 2"
nombre_rival = "Rival"
respondio_otra = False


ventana = tk.Tk()
ventana.title("Blackjack LAN - Cliente")
ventana.geometry("560x600")
ventana.configure(bg="#0b5d1e")

tk.Label(ventana, text=" BLACKJACK ", font=("Arial", 20, "bold"),
         bg="#0b5d1e", fg="white").pack(pady=(10, 2))

marco_top = tk.Frame(ventana, bg="#0b5d1e")
marco_top.pack(pady=4)

tk.Label(marco_top, text="Tu nombre:", bg="#0b5d1e", fg="white",
         font=("Arial", 11)).grid(row=0, column=0, padx=4)
entry_nombre = tk.Entry(marco_top, width=12, font=("Arial", 11))
entry_nombre.insert(0, "Jugador 2")
entry_nombre.grid(row=0, column=1, padx=4)

tk.Label(marco_top, text="IP del servidor:", bg="#0b5d1e", fg="white",
         font=("Arial", 11)).grid(row=0, column=2, padx=4)
entry_ip = tk.Entry(marco_top, width=14, font=("Arial", 11))
entry_ip.insert(0, "127.0.0.1")
entry_ip.grid(row=0, column=3, padx=4)

btn_conectar = tk.Button(marco_top, text="Conectar", font=("Arial", 10, "bold"))
btn_conectar.grid(row=0, column=4, padx=6)

lbl_estado = tk.Label(ventana, text="Escribe la IP del servidor y presiona «Conectar».",
                      bg="#0b5d1e", fg="#ffe082", font=("Arial", 10, "italic"))
lbl_estado.pack(pady=2)

lbl_rival = tk.Label(ventana, text="Rival", font=("Arial", 13, "bold"),
                     bg="#0b5d1e", fg="white")
lbl_rival.pack(pady=(10, 0))
marco_rival = tk.Frame(ventana, bg="#0b5d1e")
marco_rival.pack(pady=4)
lbl_suma_rival = tk.Label(ventana, text="Suma: ?", font=("Arial", 12),
                           bg="#0b5d1e", fg="white")
lbl_suma_rival.pack()

lbl_yo = tk.Label(ventana, text="Tú", font=("Arial", 13, "bold"),
                  bg="#0b5d1e", fg="white")
lbl_yo.pack(pady=(12, 0))
marco_yo = tk.Frame(ventana, bg="#0b5d1e")
marco_yo.pack(pady=4)
lbl_suma_yo = tk.Label(ventana, text="Suma: -", font=("Arial", 12),
                        bg="#0b5d1e", fg="white")
lbl_suma_yo.pack()

marco_botones = tk.Frame(ventana, bg="#0b5d1e")
marco_botones.pack(pady=8)
btn_pedir = tk.Button(marco_botones, text="Pedir carta", width=12,
                      font=("Arial", 11, "bold"), state=tk.DISABLED)
btn_pedir.grid(row=0, column=0, padx=8)
btn_plantarse = tk.Button(marco_botones, text="Plantarse", width=12,
                          font=("Arial", 11, "bold"), state=tk.DISABLED)
btn_plantarse.grid(row=0, column=1, padx=8)

marco_otra = tk.Frame(ventana, bg="#0b5d1e")
tk.Label(marco_otra, text="¿Jugar otra ronda?", bg="#0b5d1e",
         fg="white", font=("Arial", 11, "bold")).grid(row=0, column=0, padx=6)
btn_si = tk.Button(marco_otra, text="Sí", width=6)
btn_si.grid(row=0, column=1, padx=4)
btn_no = tk.Button(marco_otra, text="No", width=6)
btn_no.grid(row=0, column=2, padx=4)

texto_log = tk.Text(ventana, height=9, width=60, state=tk.DISABLED,
                    bg="#063d12", fg="#e8f5e9", font=("Consolas", 9))
texto_log.pack(pady=8)

def log(texto):
    texto_log.config(state=tk.NORMAL)
    texto_log.insert(tk.END, texto + "\n")
    texto_log.see(tk.END)
    texto_log.config(state=tk.DISABLED)

def pintar_mano(marco, cartas):
    for w in marco.winfo_children():
        w.destroy()
    for carta in cartas:
        if carta == "?":
            tk.Label(marco, text="?", width=3, font=("Arial", 16, "bold"),
                     bg="#1a237e", fg="white", relief=tk.RAISED, bd=3).pack(
                         side=tk.LEFT, padx=3, ipady=8)
        else:
            color = "red" if carta[-1] in ("♥", "♦") else "black"
            tk.Label(marco, text=carta, width=3, font=("Arial", 16, "bold"),
                     bg="white", fg=color, relief=tk.RAISED, bd=3).pack(
                         side=tk.LEFT, padx=3, ipady=8)

def refrescar():
    pintar_mano(marco_yo, mano_local)
    if mano_local:
        lbl_suma_yo.config(text=f"Suma: {calcular_mano(mano_local)}")
    pintar_mano(marco_rival, ["?"] + cartas_rival)
    lbl_suma_rival.config(text="Suma: ?")

def enviar(datos):
    global sock
    try:
        msg = json.dumps(datos, ensure_ascii=False) + "\n"
        sock.sendall(msg.encode("utf-8"))
    except:
        pass

def desactivar():
    btn_pedir.config(state=tk.DISABLED)
    btn_plantarse.config(state=tk.DISABLED)

def mi_turno():
    global fase
    fase = "turno_local"
    lbl_estado.config(text="¡Tu turno! Pide carta o plántate.")
    log("Tu turno.")
    if calcular_mano(mano_local) == 21:
        log("¡Tienes 21!  Te plantas automáticamente.")
        plantarse(automatico=True)
        return
    btn_pedir.config(state=tk.NORMAL)
    btn_plantarse.config(state=tk.NORMAL)

def pedir_carta():
    if fase != "turno_local":
        return
    desactivar()
    enviar({"tipo": "pedir"})

def plantarse(automatico=False):
    global fase
    if fase != "turno_local":
        return
    if not automatico:
        log(f"Te plantas con {calcular_mano(mano_local)}.")
    fase = "espera"
    desactivar()
    enviar({"tipo": "plantarse"})
    lbl_estado.config(text=f"Turno de {nombre_rival}, espera...")

def responder_otra(respuesta):
    global respondio_otra
    if respondio_otra:
        return
    respondio_otra = True
    enviar({"tipo": "otra_ronda", "respuesta": respuesta})
    log("Esperando al rival..." if respuesta else "Decidiste no seguir.")

def manejar_mensaje(msg):
    global fase, nombre_rival, respondio_otra

    tipo = msg.get("tipo")

    if tipo == "_error_conexion":
        lbl_estado.config(text="No se pudo conectar.")
        messagebox.showerror("Error", f"No se pudo conectar:\n{msg['detalle']}")
        entry_nombre.config(state=tk.NORMAL)
        entry_ip.config(state=tk.NORMAL)
        btn_conectar.config(state=tk.NORMAL)

    elif tipo == "_conectado":
        lbl_estado.config(text="Conectado. Esperando al servidor...")
        log(" Conectado al servidor.")
        enviar({"tipo": "saludo", "nombre": nombre_local})

    elif tipo == "_desconexion":
        if fase != "cerrado":
            fase = "cerrado"
            desactivar()
            marco_otra.pack_forget()
            lbl_estado.config(text="El rival se desconectó.")
            log("⚠ Conexión perdida.")
            messagebox.showinfo("Desconexión", "El otro jugador se desconectó.")

    elif tipo == "saludo":
        nombre_rival = msg.get("nombre", "Rival")
        lbl_rival.config(text=f"Rival ({nombre_rival})")
        log(f"Rival: {nombre_rival}")

    elif tipo == "inicio_ronda":
        mano_local.clear()
        mano_local.extend(msg["tu_mano"])
        cartas_rival.clear()
        cartas_rival.extend(msg["rival_visible"])
        respondio_otra = False
        marco_otra.pack_forget()
        log(f"\n━━━ RONDA {msg['ronda']} ━━━")
        refrescar()
        if msg["empiezas"]:
            mi_turno()
        else:
            fase = "espera"
            lbl_estado.config(text=f"Turno de {nombre_rival}, espera...")
            log(f"Turno de {nombre_rival}...")

    elif tipo == "tu_turno":
        mi_turno()

    elif tipo == "carta_para_ti":
        mano_local.append(msg["carta"])
        refrescar()
        log(f"Sacas: {msg['carta']}")
        estado = msg["estado"]
        if estado == "pasado":
            log("¡Te pasaste de 21! ")
            fase = "espera"
            desactivar()
        elif estado == "veintiuno":
            log("¡Tienes 21! Te plantas automáticamente.")
            fase = "espera"
            desactivar()
        else:
            btn_pedir.config(state=tk.NORMAL)
            btn_plantarse.config(state=tk.NORMAL)

    elif tipo == "rival_accion":
        accion = msg["accion"]
        if accion == "carta":
            cartas_rival.append(msg["carta"])
            log(f"{nombre_rival} pide carta → {msg['carta']}")
            refrescar()
        elif accion == "plantado":
            log(f"{nombre_rival} se planta.")
        elif accion == "pasado":
            log(f"{nombre_rival} se pasó de 21. ")

    elif tipo == "revelacion":
        fase = "fin_ronda"
        desactivar()
        mano_rival = msg["mano_rival"]
        pintar_mano(marco_rival, mano_rival)
        lbl_suma_rival.config(text=f"Suma: {msg['total_rival']}")
        log("═══ RESULTADO ═══")
        log(f"{nombre_rival}: {' '.join(mano_rival)} = {msg['total_rival']}" +
            ("  " if msg["total_rival"] > 21 else ""))
        log(f"{nombre_local}: {' '.join(mano_local)} = {msg['tu_total']}" +
            ("  " if msg["tu_total"] > 21 else ""))
        frases = {"ganaste": " ¡GANASTE!", "perdiste": "Perdiste.", "empate": "Empate."}
        log(frases[msg["resultado"]])
        lbl_estado.config(text=frases[msg["resultado"]] + "  ¿Otra ronda?")
        marco_otra.pack(pady=4)

    elif tipo == "decision_ronda":
        if msg["continuar"]:
            log("¡Empieza otra ronda!")
        else:
            marco_otra.pack_forget()
            fase = "cerrado"
            lbl_estado.config(text="Partida terminada. ¡Hasta la próxima!")
            log("Fin del juego.")

def procesar_cola():
    try:
        while True:
            msg = cola.get_nowait()
            manejar_mensaje(msg)
    except queue.Empty:
        pass
    ventana.after(100, procesar_cola)

def hilo_red(ip):
    global sock
    try:
        sock = socket.create_connection((ip, PORT), timeout=10)
        sock.settimeout(None)
    except OSError as e:
        cola.put({"tipo": "_error_conexion", "detalle": str(e)})
        return
    cola.put({"tipo": "_conectado"})
    buffer = b""
    try:
        while True:
            chunk = sock.recv(4096)
            if not chunk:
                break
            buffer += chunk
            while b"\n" in buffer:
                linea, buffer = buffer.split(b"\n", 1)
                if linea.strip():
                    cola.put(json.loads(linea.decode("utf-8")))
    except:
        pass
    cola.put({"tipo": "_desconexion"})

def conectar():
    global nombre_local
    nombre_local = entry_nombre.get().strip() or "Jugador 2"
    ip = entry_ip.get().strip()
    if not ip:
        messagebox.showwarning("Falta la IP", "Escribe la IP del servidor.")
        return
    entry_nombre.config(state=tk.DISABLED)
    entry_ip.config(state=tk.DISABLED)
    btn_conectar.config(state=tk.DISABLED)
    lbl_yo.config(text=f"Tú ({nombre_local})")
    lbl_estado.config(text=f"Conectando a {ip}:{PORT} ...")
    threading.Thread(target=hilo_red, args=(ip,), daemon=True).start()

def cerrar():
    global sock
    try:
        if sock:
            sock.close()
    except:
        pass
    ventana.destroy()

btn_conectar.config(command=conectar)
btn_pedir.config(command=pedir_carta)
btn_plantarse.config(command=plantarse)
btn_si.config(command=lambda: responder_otra(True))
btn_no.config(command=lambda: responder_otra(False))
ventana.protocol("WM_DELETE_WINDOW", cerrar)

procesar_cola()
ventana.mainloop()
