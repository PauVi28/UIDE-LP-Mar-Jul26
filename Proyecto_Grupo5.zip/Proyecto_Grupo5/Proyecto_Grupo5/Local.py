import random
import tkinter as tk
from tkinter import messagebox

def nueva_baraja():
    cartas = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10] * 4
    random.shuffle(cartas)
    return cartas

def calcular_total(mano):
    return sum(mano)

baraja = []
mano_jugador = []
mano_crupier = []

ventana = tk.Tk()
ventana.title("Blackjack")
ventana.geometry("420x380")

lbl_titulo = tk.Label(ventana, text="BLACKJACK", font=("Arial", 20))
lbl_titulo.pack(pady=10)

lbl_cartas = tk.Label(ventana, text="", font=("Arial", 12))
lbl_cartas.pack()

lbl_total = tk.Label(ventana, text="", font=("Arial", 12))
lbl_total.pack()

lbl_resultado = tk.Label(ventana, text="", font=("Arial", 12), fg="blue")
lbl_resultado.pack(pady=5)

def actualizar_pantalla():
    lbl_cartas.config(text="Tus cartas: " + str(mano_jugador))
    lbl_total.config(text="Total: " + str(calcular_total(mano_jugador)))

def pedir_carta():
    mano_jugador.append(baraja.pop())
    actualizar_pantalla()

    if calcular_total(mano_jugador) > 21:
        lbl_resultado.config(text="Te pasaste de 21. ¡Perdiste!")
        btn_carta.config(state=tk.DISABLED)
        btn_plantarse.config(state=tk.DISABLED)

def plantarse():
    # El crupier pide cartas hasta llegar a 17 o más
    while calcular_total(mano_crupier) < 17:
        mano_crupier.append(baraja.pop())

    total_jugador = calcular_total(mano_jugador)
    total_crupier = calcular_total(mano_crupier)

    if total_crupier > 21:
        resultado = "El crupier se pasó. ¡Ganaste!"
    elif total_jugador > total_crupier:
        resultado = "¡Ganaste!"
    elif total_jugador < total_crupier:
        resultado = "Perdiste."
    else:
        resultado = "Empate."

    lbl_resultado.config(
        text=f"Crupier: {mano_crupier} = {total_crupier}\n{resultado}"
    )

    btn_carta.config(state=tk.DISABLED)
    btn_plantarse.config(state=tk.DISABLED)

def nueva_partida():
    global baraja, mano_jugador, mano_crupier

    baraja = nueva_baraja()
    mano_jugador = [baraja.pop(), baraja.pop()]
    mano_crupier = [baraja.pop(), baraja.pop()]

    lbl_resultado.config(text="")
    actualizar_pantalla()

    btn_carta.config(state=tk.NORMAL)
    btn_plantarse.config(state=tk.NORMAL)

btn_carta = tk.Button(ventana, text="Pedir carta", command=pedir_carta, width=15)
btn_carta.pack(pady=8)

btn_plantarse = tk.Button(ventana, text="Plantarse", command=plantarse, width=15)
btn_plantarse.pack(pady=8)

btn_nueva = tk.Button(ventana, text="Nueva partida", command=nueva_partida, width=15)
btn_nueva.pack(pady=8)

nueva_partida()
ventana.mainloop()
