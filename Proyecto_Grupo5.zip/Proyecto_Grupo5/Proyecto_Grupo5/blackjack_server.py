import socket
import threading
import queue
import random
import json
import tkinter as tk
from tkinter import messagebox

HOST = "0.0.0.0"
PORT = 5555

def crear_baraja():
    palos = ["♠", "♥", "♦", "♣"]
    valores = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"]
    baraja = [v + p for p in palos for v in valores]
    random.shuffle(baraja)
    return baraja

def valor_carta(carta):
    v = carta[:-1]
    if v in ["J", "Q", "K"]:
        return 10
    if v == "A":
        return 11
    return int(v)

def calcular_mano(mano):
    total = sum(valor_carta(c) for c in mano)
    ases = sum(1 for c in mano if c[:-1] == "A")
    while total > 21 and ases:
        total -= 10
        ases -= 1
    return total

def resultado(yo, rival):
    if yo > 21 and rival > 21:
        return "empate"
    if yo > 21:
        return "perdiste"
    if rival > 21:
        return "ganaste"
    if yo > rival:
        return "ganaste"
    if yo < rival:
        return "perdiste"
    return "empate"

def obtener_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return "127.0.0.1"

ventana = tk.Tk()
ventana.title("Blackjack LAN - Servidor")
ventana.geometry("560x600")
ventana.configure(bg="#0b5d1e")

baraja = []
mano_local = []
mano_cliente = []
ronda = 0
fase = "esperando"
jugo_local = False
jugo_cliente = False
resp_local = None
resp_cliente = None
nombre_local = "Jugador 1"
nombre_cliente = "Rival"
conn = None
server_sock = None
cola = queue.Queue()

tk.Label(ventana, text=" BLACKJACK ", font=("Arial", 20, "bold"),
         bg="#0b5d1e", fg="white").pack(pady=(10, 2))

marco_top = tk.Frame(ventana, bg="#0b5d1e")
marco_top.pack(pady=4)

tk.Label(marco_top, text="Tu nombre:", bg="#0b5d1e", fg="white",
         font=("Arial", 11)).grid(row=0, column=0, padx=4)
entry_nombre = tk.Entry(marco_top, width=14, font=("Arial", 11))
entry_nombre.insert(0, "Jugador 1")
entry_nombre.grid(row=0, column=1, padx=4)
btn_iniciar = tk.Button(marco_top, text="Iniciar servidor", font=("Arial", 10, "bold"))
btn_iniciar.grid(row=0, column=2, padx=6)

lbl_estado = tk.Label(ventana, text="Presiona «Iniciar servidor» para esperar al rival.",
                      bg="#0b5d1e", fg="#ffe082", font=("Arial", 10, "italic"))
lbl_estado.pack(pady=2)

lbl_rival = tk.Label(ventana, text="Rival", font=("Arial", 13, "bold"),
                     bg="#0b5d1e", fg="white")
lbl_rival.pack(pady=(10, 0))
marco_rival = tk.Frame(ventana, bg="#0b5d1e")
marco_rival.pack(pady=4)
lbl_suma_rival = tk.Label(ventana, text="Suma: ?", font=("Arial", 12),
                           bg="#0b5d1e", fg="white")
lbl_suma_rival.pack()

lbl_yo = tk.Label(ventana, text="Tú", font=("Arial", 13, "bold"),
                  bg="#0b5d1e", fg="white")
lbl_yo.pack(pady=(12, 0))
marco_yo = tk.Frame(ventana, bg="#0b5d1e")
marco_yo.pack(pady=4)
lbl_suma_yo = tk.Label(ventana, text="Suma: -", font=("Arial", 12),
                        bg="#0b5d1e", fg="white")
lbl_suma_yo.pack()

marco_botones = tk.Frame(ventana, bg="#0b5d1e")
marco_botones.pack(pady=8)
btn_pedir = tk.Button(marco_botones, text="Pedir carta", width=12,
                      font=("Arial", 11, "bold"), state=tk.DISABLED)
btn_pedir.grid(row=0, column=0, padx=8)
btn_plantarse = tk.Button(marco_botones, text="Plantarse", width=12,
                          font=("Arial", 11, "bold"), state=tk.DISABLED)
btn_plantarse.grid(row=0, column=1, padx=8)

marco_otra = tk.Frame(ventana, bg="#0b5d1e")
tk.Label(marco_otra, text="¿Jugar otra ronda?", bg="#0b5d1e",
         fg="white", font=("Arial", 11, "bold")).grid(row=0, column=0, padx=6)
btn_si = tk.Button(marco_otra, text="Sí", width=6)
btn_si.grid(row=0, column=1, padx=4)
btn_no = tk.Button(marco_otra, text="No", width=6)
btn_no.grid(row=0, column=2, padx=4)

texto_log = tk.Text(ventana, height=9, width=60, state=tk.DISABLED,
                    bg="#063d12", fg="#e8f5e9", font=("Consolas", 9))
texto_log.pack(pady=8)

def log(texto):
    texto_log.config(state=tk.NORMAL)
    texto_log.insert(tk.END, texto + "\n")
    texto_log.see(tk.END)
    texto_log.config(state=tk.DISABLED)

def pintar_mano(marco, cartas):
    for w in marco.winfo_children():
        w.destroy()
    for carta in cartas:
        if carta == "?":
            tk.Label(marco, text="?", width=3, font=("Arial", 16, "bold"),
                     bg="#1a237e", fg="white", relief=tk.RAISED, bd=3).pack(
                         side=tk.LEFT, padx=3, ipady=8)
        else:
            color = "red" if carta[-1] in ("♥", "♦") else "black"
            tk.Label(marco, text=carta, width=3, font=("Arial", 16, "bold"),
                     bg="white", fg=color, relief=tk.RAISED, bd=3).pack(
                         side=tk.LEFT, padx=3, ipady=8)

def refrescar(revelar=False):
    pintar_mano(marco_yo, mano_local)
    if mano_local:
        lbl_suma_yo.config(text=f"Suma: {calcular_mano(mano_local)}")
    if revelar:
        pintar_mano(marco_rival, mano_cliente)
        lbl_suma_rival.config(text=f"Suma: {calcular_mano(mano_cliente)}")
    else:
        pintar_mano(marco_rival, ["?"] + mano_cliente[1:])
        lbl_suma_rival.config(text="Suma: ?")

def enviar(datos):
    global conn
    try:
        msg = json.dumps(datos, ensure_ascii=False) + "\n"
        conn.sendall(msg.encode("utf-8"))
    except:
        pass

def desactivar():
    btn_pedir.config(state=tk.DISABLED)
    btn_plantarse.config(state=tk.DISABLED)

def iniciar_ronda():
    global baraja, mano_local, mano_cliente, ronda
    global jugo_local, jugo_cliente, resp_local, resp_cliente, fase

    ronda += 1
    baraja = crear_baraja()
    mano_local = [baraja.pop(), baraja.pop()]
    mano_cliente = [baraja.pop(), baraja.pop()]
    jugo_local = False
    jugo_cliente = False
    resp_local = None
    resp_cliente = None
    marco_otra.pack_forget()

    cliente_empieza = (ronda % 2 == 0)

    enviar({
        "tipo": "inicio_ronda",
        "ronda": ronda,
        "tu_mano": mano_cliente,
        "rival_visible": mano_local[1:],
        "empiezas": cliente_empieza,
    })

    log(f"\n━━━ RONDA {ronda} ━━━")
    refrescar()

    if cliente_empieza:
        fase = "turno_cliente"
        lbl_estado.config(text=f"Turno de {nombre_cliente}, espera...")
        log(f"Turno de {nombre_cliente}...")
    else:
        mi_turno()

def mi_turno():
    global fase
    fase = "turno_local"
    lbl_estado.config(text="¡Tu turno! Pide carta o plántate.")
    log("Tu turno.")
    if calcular_mano(mano_local) == 21:
        log("¡Tienes 21! Te plantas automáticamente.")
        enviar({"tipo": "rival_accion", "accion": "plantado"})
        fin_turno_local()
        return
    btn_pedir.config(state=tk.NORMAL)
    btn_plantarse.config(state=tk.NORMAL)

def pedir_carta_local():
    global fase
    if fase != "turno_local":
        return
    carta = baraja.pop()
    mano_local.append(carta)
    refrescar()
    enviar({"tipo": "rival_accion", "accion": "carta", "carta": carta})
    total = calcular_mano(mano_local)
    log(f"Sacas: {carta}")
    if total > 21:
        log("¡Te pasaste de 21! ")
        enviar({"tipo": "rival_accion", "accion": "pasado"})
        fin_turno_local()
    elif total == 21:
        log("¡Tienes 21! Te plantas automáticamente.")
        enviar({"tipo": "rival_accion", "accion": "plantado"})
        fin_turno_local()

def plantarse_local():
    global fase
    if fase != "turno_local":
        return
    log(f"Te plantas con {calcular_mano(mano_local)}.")
    enviar({"tipo": "rival_accion", "accion": "plantado"})
    fin_turno_local()

def fin_turno_local():
    global jugo_local, fase
    jugo_local = True
    desactivar()
    if not jugo_cliente:
        fase = "turno_cliente"
        enviar({"tipo": "tu_turno"})
        lbl_estado.config(text=f"Turno de {nombre_cliente}, espera...")
        log(f"Turno de {nombre_cliente}...")
    else:
        revelar()

def fin_turno_cliente():
    global jugo_cliente
    jugo_cliente = True
    if not jugo_local:
        mi_turno()
    else:
        revelar()

def revelar():
    global fase
    fase = "fin_ronda"
    tl = calcular_mano(mano_local)
    tc = calcular_mano(mano_cliente)
    res_local = resultado(tl, tc)
    res_cliente = resultado(tc, tl)

    enviar({
        "tipo": "revelacion",
        "mano_rival": mano_local,
        "total_rival": tl,
        "tu_total": tc,
        "resultado": res_cliente,
    })

    refrescar(revelar=True)
    log("═══ RESULTADO ═══")
    log(f"{nombre_local}: {' '.join(mano_local)} = {tl}" + (" " if tl > 21 else ""))
    log(f"{nombre_cliente}: {' '.join(mano_cliente)} = {tc}" + (" " if tc > 21 else ""))
    frases = {"ganaste": " ¡GANASTE!", "perdiste": "Perdiste.", "empate": "Empate."}
    log(frases[res_local])
    lbl_estado.config(text=frases[res_local] + "  ¿Otra ronda?")
    marco_otra.pack(pady=4)

def responder_otra(respuesta):
    global resp_local
    if resp_local is not None:
        return
    resp_local = respuesta
    log("Esperando al rival..." if respuesta else "Decidiste no seguir.")
    comprobar_otra()

def comprobar_otra():
    global fase
    if resp_local is None or resp_cliente is None:
        return
    continuar = resp_local and resp_cliente
    enviar({"tipo": "decision_ronda", "continuar": continuar})
    if continuar:
        iniciar_ronda()
    else:
        marco_otra.pack_forget()
        fase = "cerrado"
        lbl_estado.config(text="Partida terminada. ¡Hasta la próxima!")
        log("Fin del juego.")

def manejar_mensaje(msg):
    global nombre_cliente, resp_cliente, fase, conn

    tipo = msg.get("tipo")

    if tipo == "_conectado":
        lbl_estado.config(text=f"Rival conectado desde {msg['ip']}")
        log(f" Conexión desde {msg['ip']}")
        enviar({"tipo": "saludo", "nombre": nombre_local})

    elif tipo == "_desconexion":
        if fase != "cerrado":
            fase = "cerrado"
            desactivar()
            marco_otra.pack_forget()
            lbl_estado.config(text="El rival se desconectó.")
            log(" Conexión perdida.")
            messagebox.showinfo("Desconexión", "El otro jugador se desconectó.")

    elif tipo == "saludo":
        nombre_cliente = msg.get("nombre", "Rival")
        lbl_rival.config(text=f"Rival ({nombre_cliente})")
        log(f"Rival: {nombre_cliente}")
        iniciar_ronda()

    elif tipo == "pedir":
        if fase != "turno_cliente":
            return
        carta = baraja.pop()
        mano_cliente.append(carta)
        total = calcular_mano(mano_cliente)
        if total > 21:
            estado = "pasado"
        elif total == 21:
            estado = "veintiuno"
        else:
            estado = "sigue"
        enviar({"tipo": "carta_para_ti", "carta": carta, "estado": estado})
        log(f"{nombre_cliente} pide carta → {carta}")
        refrescar()
        if estado == "pasado":
            log(f"{nombre_cliente} se pasó. ")
            fin_turno_cliente()
        elif estado == "veintiuno":
            log(f"{nombre_cliente} tiene 21.")
            fin_turno_cliente()

    elif tipo == "plantarse":
        if fase != "turno_cliente":
            return
        log(f"{nombre_cliente} se planta.")
        fin_turno_cliente()

    elif tipo == "otra_ronda":
        global resp_cliente
        resp_cliente = bool(msg.get("respuesta"))
        comprobar_otra()

def procesar_cola():
    try:
        while True:
            msg = cola.get_nowait()
            manejar_mensaje(msg)
    except queue.Empty:
        pass
    ventana.after(100, procesar_cola)

def hilo_red():
    global conn
    try:
        conn, addr = server_sock.accept()
    except:
        return
    cola.put({"tipo": "_conectado", "ip": addr[0]})
    buffer = b""
    try:
        while True:
            chunk = conn.recv(4096)
            if not chunk:
                break
            buffer += chunk
            while b"\n" in buffer:
                linea, buffer = buffer.split(b"\n", 1)
                if linea.strip():
                    cola.put(json.loads(linea.decode("utf-8")))
    except:
        pass
    cola.put({"tipo": "_desconexion"})

def iniciar_servidor():
    global server_sock, nombre_local
    nombre_local = entry_nombre.get().strip() or "Jugador 1"
    entry_nombre.config(state=tk.DISABLED)
    btn_iniciar.config(state=tk.DISABLED)
    lbl_yo.config(text=f"Tú ({nombre_local})")
    try:
        server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        server_sock.bind((HOST, PORT))
        server_sock.listen(1)
    except OSError as e:
        messagebox.showerror("Error", f"No se pudo abrir el puerto:\n{e}")
        entry_nombre.config(state=tk.NORMAL)
        btn_iniciar.config(state=tk.NORMAL)
        return
    ip = obtener_ip()
    lbl_estado.config(text=f"Esperando rival en {ip}:{PORT} ...")
    log(f"Dile al otro jugador que se conecte a: {ip}")
    threading.Thread(target=hilo_red, daemon=True).start()

def cerrar():
    try:
        if conn:
            conn.close()
        if server_sock:
            server_sock.close()
    except:
        pass
    ventana.destroy()

btn_iniciar.config(command=iniciar_servidor)
btn_pedir.config(command=pedir_carta_local)
btn_plantarse.config(command=plantarse_local)
btn_si.config(command=lambda: responder_otra(True))
btn_no.config(command=lambda: responder_otra(False))
ventana.protocol("WM_DELETE_WINDOW", cerrar)

procesar_cola()
ventana.mainloop()
